# POS-tagging

HMM词性标注demo

demo说明：

1：corpus_POS是从199801整理的语料

2：ha.py是将语料制作隐马尔可夫模型，viterbi法的开始概率，隐状态传播概率，输出发射概率文件

3：emit.txt/tran.txt/start.txt为生成的三个文件

4：viterbi.py是核心算法代码

5：mark.py是实验代码

